-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: mysql
-- Generation Time: Jan 04, 2022 at 02:21 AM
-- Server version: 8.0.27
-- PHP Version: 7.4.26

SET FOREIGN_KEY_CHECKS=0;
SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `shopme`
--

-- --------------------------------------------------------

--
-- Table structure for table `customers`
--

DROP TABLE IF EXISTS `customers`;
CREATE TABLE `customers` (
  `id` bigint NOT NULL,
  `address_line1` varchar(64) NOT NULL,
  `address_line2` varchar(64) DEFAULT NULL,
  `city` varchar(64) NOT NULL,
  `created_time` datetime(6) DEFAULT NULL,
  `email` varchar(45) NOT NULL,
  `enabled` bit(1) NOT NULL,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `password` varchar(64) NOT NULL,
  `phone_number` varchar(15) NOT NULL,
  `postal_code` varchar(10) NOT NULL,
  `state` varchar(45) NOT NULL,
  `verification_code` varchar(64) DEFAULT NULL,
  `country_id` bigint NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Dumping data for table `customers`
--

INSERT INTO `customers` (`id`, `address_line1`, `address_line2`, `city`, `created_time`, `email`, `enabled`, `first_name`, `last_name`, `password`, `phone_number`, `postal_code`, `state`, `verification_code`, `country_id`) VALUES
(1, '30 Do Huy Uyen', 'Son Tra district', 'Da Nang', '2020-10-09 03:18:58.000000', 'lehoanganhvn@gmail.com', b'1', 'Anh', 'Le Hoang', '$2a$10$ZQdbl6XeG/Z3frq.iJxnyucOhaoLhaa5BocnHnZKRPAntcZqQR9bu', '09123456789', '550000', '', NULL, 242),
(2, '2320  Romano Street', '', 'Cambridge', '2020-10-09 03:21:29.000000', 'lorraine.allbright@outlook.com', b'1', 'Lorraine', 'Allbright', '$2a$10$II70xzaNTXp8WjJgGBq5k.xiDd8qiTp1yGPaCULGVeHtej/Hieb4O', '781-434-1947', '2142', 'Massachusetts', NULL, 234),
(3, '4703  Goyeau Ave', '', 'Windsor', '2020-10-09 03:24:42.000000', 'nancy.bass2001@yahoo.com', b'1', 'Nancy', 'C Bass', '$2a$10$iCc2M47GrRfzWV7/nrdZpuzkjLSxH5VEs1t02E55428eToiFo8pT6', '519-791-4692', 'N9A 1H9', 'Ontario', NULL, 39),
(4, '4103  Tolmie St', '', 'Vancouver', '2020-06-09 03:27:48.000000', 'brian.purcell3@gmail.com', b'1', 'Brian', 'Purcell', '$2a$10$mHz6KD.k5OTuTw9JWsa8OOZiF8gWxFRw6tjzIMxrx6GuaF2d.bvxG', '604-269-1384', 'V6M 1Y8', 'British Columbia', NULL, 39),
(5, '934A  Small Street', 'Amish Country Byway', 'Berlin', '2020-10-09 03:29:39.000000', 'tina.jamerson@gmail.com', b'1', 'Tina', 'D Jamerson', '$2a$10$zS.WEDVdrfraeTYXkh6kru0YT4dg14daWwxrPZKwImwt1S8I8Cbaa', '5139670375', '44610', 'Ohio', NULL, 234),
(6, '3087 Marietta Street', '', 'Vallejo', '2020-10-10 11:11:19.000000', 'christopherseldonusa@gmail.com', b'1', 'Christopher ', 'Seldon', '$2a$10$kBu.WfmGeYpcp.gNCVosx.2PY6dhUahdjPolgSOvYjY4DcUWRtnUm', '214-407-6337', '94590', 'California', NULL, 234),
(7, '56  Berkeley Rd', '', 'Stretton-on-Dunsmore', '2020-10-11 03:36:04.000000', 'alex.stevenson@outlook.com', b'1', 'Alex', 'Stevenson', '$2a$10$og9uLgfaPjMbN0UQFPXQeeVhgfuArv3QQXLhM7ZfS4M.9j4Yp/Ksi', '078 7586 952', 'CV23 3XN', '', NULL, 78),
(8, '101  Gordon Terrace', '', 'Barton', '2020-10-11 03:38:09.000000', 'ethan.k.john@gmail.com', b'1', 'Ethan', 'Jones', '$2a$10$8Zc6kveZk1FR0HzVUQK/DuSQWFf2oGujkmDreapVXW0BtfDchP0yG', '070 2534 460', 'SY14 4FH', '', NULL, 78),
(9, 'B 3/12, Part 1', '', 'Delhi', '2020-10-11 03:40:04.000000', 'pandu.shan03@gmail.com', b'1', 'Pandu', 'Shan', '$2a$10$Iybz9lJhA6FoeO7tviEWIuLaO4fC9lwjiiHwKCD0B5q4DLJ066mVW', '042375292', '110009', 'Delhi', NULL, 106),
(10, 'Shop No 6, Gk Nagar No 3', 'Mahavir Darshan, Shankar Lane, Kandivali (west)', 'Mumbai', '2020-10-11 03:43:12.000000', 'ahjj.thaker2000@gmail.com', b'1', 'Ahjaja', 'Thaker', '$2a$10$QKr/DFMbrX9ItxJCcTd.RuiD.H8BgsThxfZMEAmAas6yGOdJZkH9S', '02228611610', '400067', 'Maharashtra', NULL, 106),
(11, '53 Balanagar', '', 'Hyderabad', '2020-10-11 03:44:55.000000', 'meena.gara@yahoo.com', b'1', 'Meena', 'Gara', '$2a$10$SF6oz1JICybgPDOdrnTjFODxJBlCcUfj.HRF.TanU2pdjFcIT3X7S', '04023775438', '500042', 'Andhra Pradesh', NULL, 106),
(12, '112 Gagan Deep Building', 'Rajendra Place', 'Delhi', '2020-10-11 03:46:25.000000', 'jahnu.mishra@gmail.com', b'1', 'Jahnu', 'Mishra', '$2a$10$UIQGuwvF9WU3cge7cGHBge6aX6/dGRpwqD8GuCxBghTpDos9Hx9yW', '01125713815', '110008', 'Delhi', NULL, 106),
(13, 'B/7/a Bharat Ngr, Grant Road', '', 'Mumbai', '2020-10-12 10:09:30.000000', 'saka.prakash@yahoo.com', b'0', 'Saka', 'Prakash', '$2a$10$Q.Ctg6lFyvVEJ7ZnIuCIZ.UK5RlXuY2Iwwru4x.n9gtptDuhVLxRu', '02223011775', '400007', 'Maharashtra', NULL, 106),
(14, '37 , Dhake Colony, J.p.rd, Andheri (west)', '', 'Mumbai', '2020-10-12 10:10:50.000000', 'gautam1988@gmail.com', b'1', 'Gautam', 'Nayak', '$2a$10$nQjus79bd4dwNeEHTJ96U.Q7GIMffZQ7lqORWYv9VQQyh.9oqSgOK', '02226200995', '400058', 'Maharashtra', NULL, 106),
(15, '181 /, th Floor, M G Road, Burrabazar', '', 'Kolkata', '2020-10-12 10:12:04.000000', 'cheema1994@gmail.com', b'1', 'Avatar', 'Cheema', '$2a$10$NNQmIhQn6V1ZR9VpIbQL6OLpiLF.dJ.8qTDegkD3ZiDeMmwjSCyRW', '03322684941', '700007', 'West Bengal', NULL, 106),
(16, '456 Alexandra Road #16-02 NOL', 'Building Singapore 119962', 'Singapore', '2020-10-12 10:13:00.000000', 'jianzhou2000@gmail.com', b'1', 'Jianhong', 'Zhou', '$2a$10$QEOF7Xeue1enl9COCgB/deSu2DIewIlyEHGDm83hjpz3iNLkmD0sm', '65-6278 9444', '119962', '', NULL, 199),
(17, 'Braddell Tech 13 Lorong 8 Toa Payoh #04-01 319261', '', 'Singapore', '2020-10-12 10:14:03.000000', 'sugeng1208@outlook.com', b'1', 'Su', 'Geng', '$2a$10$CVLvsCqcbzWcsRN/ZfGcAOr5wZAUIITu9kqG7.U2lWo4MgtIdITDa', '062566046', '319261', '', NULL, 199),
(18, '1053  Broadway Avenue', '', 'Chattanooga', '2020-10-12 10:15:12.000000', 'alisa.willcox7@gmail.com', b'1', 'Alisa', 'Willcox', '$2a$10$pBLzCgKPXfJsMiCHFB9BweUamtoJXnbPlh7eheH7zK02v/QW3UgPK', '423-893-1283', '37421', 'Tennessee', NULL, 234),
(19, '79 Masthead Drive', '', 'Great Keepel Island', '2020-10-12 10:16:23.000000', 'chelsea.greener@gmail.com', b'1', 'Chelsea', 'Greener', '$2a$10$cyrxmp9dwNhUAEYqPiMHHO6n9vvLqgS/tbcYjaeyIMekfd35pvnOm', '(07) 4918 39', '4700', 'Queensland', NULL, 14),
(20, '37 Grayson Street', '', 'Matong', '2020-10-12 10:17:27.000000', 'spender.de.bavay@gmail.com', b'1', 'Spencer', 'De Bavay', '$2a$10$LQT8mw/ZGHz1W5pd4/iDyuNjwv7yJSKKJUXnXWf6xAB46M5wDUOVG', '(02) 6146 87', '2652', 'New South Wales', NULL, 14),
(21, 'Alt Reinickendorf 61', '', 'Schwenningen', '2020-10-16 04:20:15.000000', 'konig.daniela@gmail.com', b'0', 'Daniela', 'Konig', '$2a$10$E6g8TKWzT6wPyGma.O3SweI4mqEMQyavjiy/qUk9ayyAQ7/FN/eq.', '08274368060', '72477', 'Baden-Württemberg', NULL, 58),
(22, 'Ba Vi, Thanh Chuong', 'Soc Son', 'Ha Noi', '2020-11-12 14:35:37.000000', 'tannguyenminh@gmail.com', b'1', 'Tan', 'Nguyen Minh', '$2a$10$c9u299wIXYQ4GuNUtthJRO4/fxb/qaPXBIcgLqo.OzTqBM2e5Erm2', '0987667887', '142870', 'Ha Noi', NULL, 242),
(23, '30 Do Huy Uyen', 'An Hai Bac district', 'Da Nang', '2021-01-14 02:35:51.000000', 'trangquynh269@gmail.com', b'1', 'Trang', 'Le Thi Quynh', '$2a$10$pFQajpIUy38PV61fucqxmugLtQerPid3N1LvP2MsSlMMuUG283.Cm', '0922664450', '552000', 'Da Nang', NULL, 242),
(24, '123 Truc Bach', 'Tay Ho', 'Ha Noi', '2021-01-10 02:40:58.000000', 'nguyen.tuan.son@gmail.com', b'1', 'Son', 'Nguyen Tuan', '$2a$10$4YwxikvvFeDknQxWXoYHK.s0JicA2E1U4fjaomQ/tktD4Xx9R.Di6', '0984457819', '127890', 'Hanoi', NULL, 242),
(25, '14H8 Phan Van Truong', 'Cau Giay', 'Ha Noi', '2020-01-14 02:56:08.000000', 'minhthu20@gmail.com', b'1', 'Thu', 'Trinh Minh', '$2a$10$80H.3RSBQS1iT6hCJI56suOJFE.pBUx.DyhnmDv/ZjOGiJAQxjR6K', '0977882312', '113000', 'Hanoi', NULL, 242),
(26, '256A Vo Van Kiet', 'Phuoc My', 'Da Nang', '2021-01-16 10:15:37.000000', 'tran.thi.mai@gmail.com', b'1', 'Mai', 'Tran Thi', '$2a$10$YkVzbGU89318I2nL8z.NGeJN77.UJCavjY7PH7x3LfL1zIEOVzF7m', '0954876291', '555000', 'Da Nang', NULL, 242),
(27, '620 Bach Dang', 'Hai Chau', 'Da Nang', NULL, 'nguyen.hoang.bach@gmail.com', b'0', 'Bach', 'Nguyen Hoang', '$2a$10$G3RLX9mmiMafu0MxTomJp.43lX2khhp0IOKN4oZSDK689dRt71zGq', '0910405069', '554000', 'Da Nang', NULL, 242),
(28, 'M 55 2nd Floor, Part 2', '', 'Delhi', '2020-05-16 10:28:38.000000', 'ravi.kumar2009@gmail.com', b'1', 'Ravi', 'Kumar', '$2a$10$yYkH67VJ6LVGScLHvxtyyOTCslPiY3ZM0SYArvur0JR8F6IlGy.Gu', '026715849', '110048', 'Delhi', NULL, 106),
(29, 'Choa Chu Kang Crescent, 683690', '', 'Singapore', '2021-01-17 10:25:06.000000', 'xue.hao.chu@gmail.com', b'1', 'Xue', 'Hao Chu', '$2a$10$suovD4HuFHy632QdAQnNTOwyTwHLs4NI8mT0gARBNxavM0IXl.HdW', '081005992', '683690', '', NULL, 199),
(30, '30 Robinson Road', '#03-01B ROBINSON TOWERS', 'Singapore', '2020-04-12 10:35:37.000000', 'mo.liang.237@gmail.com', b'1', 'Mo', 'Liang', '$2a$10$JKIV3Hi4phMMKU/p2tqH8OXZaKNboZAwX6/nHdFoxWbeohie7NDuu', '063237730', '048546', '', NULL, 199),
(31, '260 Orchard Road, The Heeren', '04-30/31 238855', 'Singapore', '2021-01-18 10:47:17.000000', 'chan.ding.97@gmail.com', b'1', 'Chan', 'Ding', '$2a$10$KlcH7aIiy/Hvt3NhCYbDH.toghsP2CbeBY7ZO9YT03o9dLkdNluBS', '6567321372', '238855', '', NULL, 199),
(32, '70 Guild Street', '', 'London', '2021-01-20 11:03:49.000000', 'zak.carey.91@gmail.com', b'0', 'Zak', 'Carey', '$2a$10$E1IxQO8LTXWF0diVBB7bfOcwc8wwtWHu4dhRx3zkGemtcsb1Mf32G', '0795602121', 'N8 1HG', '', NULL, 78),
(33, '922  Emeral Dreams Drive', '', 'Chicago', '2020-12-26 11:20:07.000000', 'katherin.mc.knight@live.com', b'1', 'Katherine', 'McKnight', '$2a$10$9ZbxZO2gJul3ups2FXU9se3vd3d5zn0VRXQnp0l1bS04dq3UHy5g2', '8153287288', '60601', 'Illinois', NULL, 234),
(34, '1482  Rosewood Lane', '', 'New York', '2020-05-26 11:34:41.000000', 'pasty.aston.89@live.com', b'1', 'Pasty', 'Aston', '$2a$10$eISh5FVdov6DSOWeXpNeVeieJOwGe8gBC1zrLfKUKVqWrBFeIaMKy', '2129229661', '10016', 'New York', NULL, 234),
(35, 'Shop No 2, Shobhana Bldg.', 'Tilak Road, Opp. Dph, Santacruz (west)', 'Mumbai', '2020-09-01 09:26:20.000000', 'rekha.makavana@gmail.com', b'1', 'Rekha', 'Makavana', '$2a$10$52Ah7rPRiReZ8FsQBRATfOlJl.XQfwGGaqa3vP6Z9uBKc7ADz7yCO', '02226493101', '400054', 'Maharashtra', NULL, 106),
(36, '19 Shirley Street', '', 'Yatala', '2021-02-01 08:42:40.000000', 'flynn.hackett.au@gmail.com', b'1', 'Flynn', 'Hackett', '$2a$10$8oaaz3VHFE/PqpRMPnvABuWLZSl9lCT3plI8aMMejqJeVtv3bNUH.', '073758521', '4207', 'Queensland', NULL, 14);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `customers`
--
ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `UK_rfbvkrffamfql7cjmen8v976v` (`email`),
  ADD KEY `FK7b7p2myt0y31l4nyj1p7sk0b1` (`country_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `customers`
--
ALTER TABLE `customers`
  MODIFY `id` bigint NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `customers`
--
ALTER TABLE `customers`
  ADD CONSTRAINT `FK7b7p2myt0y31l4nyj1p7sk0b1` FOREIGN KEY (`country_id`) REFERENCES `countries` (`id`);
SET FOREIGN_KEY_CHECKS=1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
