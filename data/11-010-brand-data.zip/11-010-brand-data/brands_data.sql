-- MariaDB dump 10.19  Distrib 10.4.21-MariaDB, for Win64 (AMD64)
--
-- Host: 127.0.0.1    Database: shopmedb
-- ------------------------------------------------------
-- Server version	10.4.21-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `brands_categories`
--

DROP TABLE IF EXISTS `brands_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands_categories` (
  `brand_id` bigint(20) NOT NULL,
  `category_id` bigint(20) NOT NULL,
  PRIMARY KEY (`brand_id`,`category_id`),
  KEY `FK6x68tjj3eay19skqlhn7ls6ai` (`category_id`),
  CONSTRAINT `FK58ksmicdguvu4d7b6yglgqvxo` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`),
  CONSTRAINT `FK6x68tjj3eay19skqlhn7ls6ai` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands_categories`
--

LOCK TABLES `brands_categories` WRITE;
/*!40000 ALTER TABLE `brands_categories` DISABLE KEYS */;
INSERT INTO `brands_categories` (`brand_id`, `category_id`) VALUES (1,2),(1,10),(1,11),(1,12),(2,2),(3,2),(3,10),(3,11),(4,5),(4,6),(5,18),(5,24),(5,27),(5,29),(5,31),(6,1),(6,24),(6,27),(6,29),(7,2),(7,10),(8,2),(8,9),(9,4),(9,5),(9,6),(9,7),(9,14),(9,15),(10,5),(10,6),(10,7),(10,14),(10,15),(10,18),(10,24),(10,25),(10,27),(10,29),(11,10),(12,9),(13,9),(14,10),(14,11),(14,12),(15,11),(16,12),(17,13),(18,13),(19,13),(20,13),(20,19),(21,14),(21,15),(22,14),(22,25),(23,14),(23,15),(24,14),(25,15),(26,15),(27,17),(28,17),(29,17),(30,17),(31,18),(32,19),(33,19),(34,19),(35,19),(36,5),(36,6),(36,7),(37,5),(37,6),(37,7),(38,5),(38,6),(38,7),(39,5),(39,22),(40,5),(40,6),(40,7),(40,25),(40,26),(40,28),(40,30),(41,7),(42,7),(43,22),(43,23),(44,23),(45,23),(45,30),(46,24),(47,26),(47,29),(48,26),(49,27),(49,29),(50,28),(51,29),(52,29),(53,30),(54,31);
/*!40000 ALTER TABLE `brands_categories` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `logo` varchar(128) COLLATE utf8_unicode_ci DEFAULT NULL,
  `name` varchar(128) COLLATE utf8_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UK_oce3937d2f4mpfqrycbr0l93m` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=55 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brands`
--

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
INSERT INTO `brands` (`id`, `logo`, `name`) VALUES (1,'Canon.png','Canon'),(2,'Fujifilm.png','Fujifilm'),(3,'Sony.png','Sony'),(4,'HP.png','HP'),(5,'SanDisk.png','SanDisk'),(6,'Western Digital.png','Western Digital'),(7,'Panasonic.png','Panasonic'),(8,'Pelican.png','Pelican'),(9,'Apple.png','Apple'),(10,'Samsung.png','Samsung'),(11,'Olympus.png','Olympus'),(12,'Caden.png','CADeN'),(13,'amazonbasics.png','AmazonBasics'),(14,'Nikon.png','Nikon'),(15,'Neewer.png','Neewer'),(16,'Sigma.png','Sigma'),(17,'Bosch.png','Bosch'),(18,'Joby.png','Joby'),(19,'GoPro.png','GoPro'),(20,'Manfrotto.png','Manfrotto'),(21,'Google.png','Google'),(22,'LG.png','LG'),(23,'Motorola.png','Motorola'),(24,'Pantech.png','Pantech'),(25,'Huawei.png','Huawei'),(26,'Xiaomi.png','Xiaomi'),(27,'Hovamp.png','HOVAMP'),(28,'Aioneus.png','Aioneus'),(29,'XIAE.png','XIAE'),(30,'Everyworth.png','Everyworth'),(31,'Lexar.png','Lexar'),(32,'Nulaxy.png','Nulaxy'),(33,'Fitfort.png','Fitfort'),(34,'PopSocket.png','PopSockets'),(35,'SHAWE.png','SHAWE'),(36,'Lenovo.png','Lenovo'),(37,'Acer.png','Acer'),(38,'Dell.png','Dell'),(39,'Intel.png','Intel'),(40,'ASUS.png','ASUS'),(41,'Microsoft.png','Microsoft'),(42,'DragonTouch.png','DragonTouch'),(43,'AMD.png','AMD'),(44,'XFX.png','XFX'),(45,'MSI.png','MSI'),(46,'Seagate.png','Seagate'),(47,'Corsair.png','Cosair'),(48,'Thermaltake.png','Thermaltake'),(49,'Kingston.png','Kingston'),(50,'Creative.png','Creative'),(51,'Crucial.png','Crucial'),(52,'HyperX.png','HyperX'),(53,'Gigabyte.png','Gigabyte'),(54,'TP-Link.png','TP-Link');
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-11-18 15:30:47
